﻿namespace WindowsFormsApplication2
{
    partial class Betting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.cmdBet = new System.Windows.Forms.Button();
            this.lblBalance = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.numBet = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numBet)).BeginInit();
            this.SuspendLayout();
            // 
            // cmdBet
            // 
            this.cmdBet.Location = new System.Drawing.Point(98, 107);
            this.cmdBet.Name = "cmdBet";
            this.cmdBet.Size = new System.Drawing.Size(80, 21);
            this.cmdBet.TabIndex = 7;
            this.cmdBet.Text = "&Bet";
            this.cmdBet.UseVisualStyleBackColor = true;
            this.cmdBet.Click += new System.EventHandler(this.cmdBet_Click_1);
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalance.Location = new System.Drawing.Point(81, 60);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(107, 13);
            this.lblBalance.TabIndex = 6;
            this.lblBalance.Text = "Balance: $500.00";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(66, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Current bet:";
            // 
            // numBet
            // 
            this.numBet.Location = new System.Drawing.Point(141, 81);
            this.numBet.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numBet.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numBet.Name = "numBet";
            this.numBet.Size = new System.Drawing.Size(62, 20);
            this.numBet.TabIndex = 4;
            this.numBet.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // Betting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(264, 167);
            this.Controls.Add(this.cmdBet);
            this.Controls.Add(this.lblBalance);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numBet);
            this.Name = "Betting";
            this.Text = "Betting";
            this.Load += new System.EventHandler(this.Betting_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numBet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button cmdBet;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numBet;
    }
}