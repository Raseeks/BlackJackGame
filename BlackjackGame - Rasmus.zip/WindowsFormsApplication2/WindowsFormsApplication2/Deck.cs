﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication2
{
    class Deck
    {
        // Luodaan "Deck" Luokalle property "cardList", joka on lista "card" luokan objekteja, On tallessa kaikki " Deck objektin kortit (card) listassa
        public List<card> cardsList = new List<card>();
        // Luodaan uusi Random objekti luokalle "RNG"
        private static Random RNG = new Random();


        // Täyttää pakkaa card.suitesin avulla
        public void fillDeck()
        {
            card.Suites SuiteH = (card.Suites)(0);
            card.Suites SuiteD = (card.Suites)(1);
            card.Suites SuiteC = (card.Suites)(2);
            card.Suites SuiteS = (card.Suites)(3);

            //looppa kortit arvojen 1-13 välillä
            for (int i = 1; i <= 13; i++)
            {
                // loop trough each suite in deck
                //foreach (card.Suites suite in (card.Suites)
                //{

                // }
                cardsList.Add(new card(i, SuiteH));
                cardsList.Add(new card(i, SuiteD));
                cardsList.Add(new card(i, SuiteC));
                cardsList.Add(new card(i, SuiteS));
            }
        }


        // sufflaa kortit 
        public void Shuffle()
        {
            for (int n = cardsList.Count - 1; n > 0; --n)
            {
                int k = RNG.Next(n + 1);
                card temp = cardsList[n];
                cardsList[n] = cardsList[k];
                cardsList[k] = temp;
            }
        }
        // Ottaa kortti
        public card pickCard()
        {
            int randomIndex = RNG.Next(cardsList.Count);
            card temp = cardsList[randomIndex];
            cardsList.RemoveAt(randomIndex);
            return temp;
        }

        public int countPointsAceOne()
        {
            int returnValue = 0;
            int aces = 0;
            
            foreach (card c in cardsList)
            {
                if (c.value == 1)
                {
                    aces++;
                }
                returnValue += c.getPoints();
            }

            for (int i = 0; i < aces; i++)
            {
                returnValue -= 10;
            }

            return returnValue;

        }

        // Korttien pisteet

        //method / function
        public int countPoints()
        {
            int aces = 0;
            int total = 0;
            foreach (card c in cardsList)
            {
                if(c.value == 1)
                {
                    aces++;
                }
                total += c.getPoints();
            }
            for(int i = 0; i < aces; i++)
                if (total < 21)
                {
                    total -= 10;
                }
            return total;
        }

    }
}