﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication2
{
    class card

    {
        public enum Suites
        {
            Hearts,
            Diamonds,
            Clubs,
            Spades
        }

        //public static String[] AllSuites = Enum.GetValues(typeof(Suites))
        public int value { get; set; }


            // property, objecti "Suites" - luokasta.
        public Suites Suite { get; set; }



        // Constructor, Kutsutaan kun luokasta luodaan objekti
        public card(int value, Suites Suite)
        {
            this.value = value;
            this.Suite = Suite;
        }

        public int getPoints ()
        {
            switch (value)
            {
                case 1:
                    return 11;
                case 11:
                case 12:
                case 13:
                    return 10;
                default:
                    return value;
            }
        }
        //Static 
        public static Bitmap GetPictureRecourcex(string key)
        {
            return WindowsFormsApplication2.CardPictures.ResourceManager.GetObject(key) as Bitmap;
        }
        public string getPictureKey()
        {
            char suite = getSuiteId();
            string value = getValueId();
            return suite + value;
        }

        // returns suiteId as 'C' or 'H' or 'D' or 'S'
        private char getSuiteId()
        {
            switch (Suite.ToString())
            {
                case "Hearts": return 'H';
                case "Diamonds": return 'D';
                case "Clubs": return 'C';
                case "Spades": return 'S';
                default: return 'X';

            }
        }
        private string getValueId()
        {
            switch (value)
            {
                case 11: return "J";
                case 12: return "Q";
                case 13: return "K";
                default: return value.ToString(); 

            }
        }

    }

}
