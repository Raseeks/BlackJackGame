﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Betting : Form
    {
        public static decimal Bet = 50;
        public static decimal Balance = 500;

        public Betting()
        {
            InitializeComponent();
        }

        private void Betting_Load(object sender, EventArgs e)
        {
            lblBalance.Text = "Balance: $" + Balance.ToString("#0.00");
            numBet.Maximum = Balance;
        }

        private void cmdBet_Click(object sender, EventArgs e)
        {
            Bet = numBet.Value;
            if (Balance == 0)
            {
                MessageBox.Show(null, "Sorry, you are out of money to bet with!",
                    "Say Good-bye to Vegas!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Application.Exit();
            }
            else if (Bet > Balance)
                MessageBox.Show("Sorry, you do not have $" + Bet + " to bet. " +
                   "Please choose a lower amount.", "Bet too high");
            else
            {
                Balance -= Bet;
                lblBalance.Text = "Balance: $" + Balance.ToString();
                this.Close();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblBalance_Click(object sender, EventArgs e)
        {

        }

        private void numBet_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void cmdBet_Click_1(object sender, EventArgs e)
        {

        }
    }
}
