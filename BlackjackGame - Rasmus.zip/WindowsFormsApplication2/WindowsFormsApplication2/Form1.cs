﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        // Luodaan "Deck" -luokasta uusi object nimeltä "playDeck". "playDeck" pitää sisällään pelin jaettavissa olevat kortit.
        Deck PlayDeck = new Deck();
        // Luodaan objekti jakajan korteille, jossa on tallessa pelaajalle jaetut kortit.
        Deck dealerCards = new Deck();
        // Luodaan objekti jakajan korteille, jossa on tallessa jakajalle jaetut kortit.

        Deck PlayerCards = new Deck();

        int dealerWins = 0;
        int playerWins = 0;

        Deck calculateOddsDeck = new Deck();


        bool hideFirst = true;
        bool autoPlay = false;

        private System.Timers.Timer timer = null;

        public static Dictionary<string, Bitmap> CARD_PICTURES =
            new Dictionary<string, Bitmap>();

        //peli alkaa
        bool gameStarted = false;


        // tämä on luokan constructor
        public Form1()
        {
            InitializeComponent();


            PlayDeck.fillDeck();
            //PlayDeck.Shuffle();
            calculateOddsDeck.fillDeck();

            foreach (card c in PlayDeck.cardsList)
            {
                string key = c.getPictureKey();
                CARD_PICTURES.Add(key, card.GetPictureRecourcex(key));
            }





            int helper = 5;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }




        private bool painettu = false;


        //Aloittaa pelin jakamalla ensimmäist kortit ja päivittää scenen lopussa
        private void button1_Click(object sender, EventArgs e)
        {
            play();
            SoundPlayer simpleSound = new SoundPlayer(@"C:\Users\rasmus.kuosmanen\Desktop\Video-Game-Beep-Sound-Effect.wav");
            simpleSound.Play();
        }


        //updeittaa scenea
        private void updateScene()
        {


            //    if (gameStarted)
            //   {
            //       button1.Enabled = false;
            //   }
            //    else
            //   {
            //      button1.Enabled = true;
            //  }
            button1.Enabled = !gameStarted;
            button1.Visible = !gameStarted;

            label18.Text = String.Format("{0:0.00}",
    OddsCalculator.OverDraw(PlayerCards,
        calculateOddsDeck));
            {

            }

                if (hideFirst && gameStarted)
            {
                label15.Text = "?";
                //label 16 tulee pelaajan pisteet
                label16.Text = PlayerCards.countPoints().ToString();

                label19.Text = String.Format("{0:0.00}",
                    OddsCalculator.DealerWins(dealerCards.cardsList[1],
                    PlayerCards.countPoints()));
            }
            else
            {
                //label 15 tulee dealerin pisteet
                label15.Text = dealerCards.countPoints().ToString();
                label20.Text = (playerWins - dealerWins).ToString();


            }




            List<Label> playerLabels = new List<Label>
            {
                label1,
                label2,
                label3,
                label4,
                label5

            };

            // näille labeleille menee dealerin kortit
            List<Label> dealerLabels = new List<Label>
            {
                label6,
                label7,
                label8,
                label9,
                label10

            };
            // näille labeleille menee pelaajan kortit


            List<PictureBox> PlayerBoxes = new List<PictureBox>
            {
                pictureBox1,
                pictureBox2,
                pictureBox3,
                pictureBox4,
                pictureBox5
            };
            List<PictureBox> dealerBoxes = new List<PictureBox>
            {
                pictureBox6,
                pictureBox7,
                pictureBox8,
                pictureBox9,
                pictureBox10
            };

            //renderöi pelaajan kortit
            renderCards(playerLabels, PlayerBoxes, PlayerCards.cardsList, false);
            //renderöi dealerin kortit
            renderCards(dealerLabels, dealerBoxes, dealerCards.cardsList, hideFirst);

        }



        //button 2 määrittää, jos kortteja on yli 21 niin häviää ja jos dealereilla on 17 tai enemmän niin se voittaa.
        private void button2_Click_1(object sender, EventArgs e)
        {

            Hit();

        }

    


private void renderCards(List<Label> labels, List<PictureBox> boxes, List<card> cards, bool hide)
        {
            bool cardHidden = false;
            IEnumerator enumerator =
                cards.GetEnumerator();

            IEnumerator enumeratorBoxes = boxes.GetEnumerator(); 

            foreach (Label I in labels)
            {
                card c = enumerator.MoveNext() 
                    ? (card)enumerator.Current : null;

                PictureBox pb = enumeratorBoxes.MoveNext()
                    ? (PictureBox)enumeratorBoxes.Current : null;
                if (hide == true && cardHidden == false)
                {
                    I.Text = "";
                    pb.Image = card.GetPictureRecourcex("kortti");
                    cardHidden = true;
                }

                else if(c != null && pb != null)
                {
                    I.Text = (c.value.ToString() + " " + c.Suite);
                    pb.Image = card.GetPictureRecourcex(c.getPictureKey());
                }
                else
                {
                    I.Text = "";
                    pb.Image = null;

                }
            }
        }



        private void Lose ()
        {
            dealerWins++;
            if (!autoPlay)
            {
                //tässä tulee messagebox esille kun dealaeri on voittanut pelin
                MessageBox.Show("You lost! " +
                "You Had: " + PlayerCards.countPoints() +
                (" ") +
                " Dealer had " + dealerCards.countPoints());

                SoundPlayer simpleSound = new SoundPlayer(@"C:\Users\rasmus.kuosmanen\Desktop\record.wav");
                simpleSound.Play();
            }
            reset();
        }

        private void Win()
        {
            playerWins++;
            if (!autoPlay)
            {
                //tässä tulee messagebox esille kun pelaaja on voittanut pelin
                MessageBox.Show("You Win! " +
                "You Had: " + PlayerCards.countPoints() +
                " Dealer had " + dealerCards.countPoints());

                SoundPlayer simpleSound = new SoundPlayer(@"C:\Users\rasmus.kuosmanen\Desktop\WIN-sound-effect.wav");
                simpleSound.Play();
            }
            reset();
        }


        //pelin resetaus
        private void reset()
        {
            if (autoPlay)
            {
                updateScene();
            }
            gameStarted = false;
            dealerCards.cardsList.Clear();
            PlayerCards = new Deck();
            hideFirst = true;

            if (!autoPlay)
            {
                updateScene();
            }

           // updateScene();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            pass();
        }




        private void BlackjackWin()
        {
            playerWins++;
            if(!autoPlay)
            {
                //tässä tulee messagebox esille kun pelaaja on voittanut pelin
                MessageBox.Show("Voitit blackjackin " +
                "You Had: " + PlayerCards.countPoints() +
                "Dealer had " + dealerCards.countPoints());
                SoundPlayer simpleSound = new SoundPlayer(@"C:\Users\rasmus.kuosmanen\Desktop\jellyfish-jam.wav");
                simpleSound.Play();
            }
            reset();
        }


        private void Tie()
        {
            playerWins++;
            if (!autoPlay)
            {
                MessageBox.Show("Tie Motherfucker");

            }
        }




        private void button4_Click_1(object sender, EventArgs e)
        {
            autoPlay = true;

            timer = new System.Timers.Timer((double)numericUpDown1.Value);
            timer.Elapsed += autoPlayTimerEvent;
            timer.AutoReset = true;
            timer.Enabled = true;

            updateScene();
        }
        private void autoPlayTimerEvent(Object source,
            ElapsedEventArgs e)
        {
            this.Invoke(new MethodInvoker(delegate ()
            {
                if (PlayDeck.cardsList.Count() < 500)
                {
                    PlayDeck.cardsList.Clear();
                    for(int i = 0; i < 10; i++)
                    {
                        PlayDeck.fillDeck();
                    }
                }

                play();
            }));
          
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            this.WindowState = FormWindowState.Normal;
            this.Focus(); this.Show();
        }
        private void play()
        {

            //hävitttää napit kun "pelaa" nappia on painettu
            if (painettu = true)
            {
                button2.Visible = true;
                button3.Visible = true;
            }

            gameStarted = true;


            //Lisää Korttilistaan dealerin kortit
            dealerCards.cardsList.Add(PlayDeck.pickCard());
            //Lisää Korttilistaan dealerin kortit
            dealerCards.cardsList.Add(PlayDeck.pickCard());

            //Tämä lisää korttilistaan pelaajan kortit
            PlayerCards.cardsList.Add(PlayDeck.pickCard());
            //Tämä lisää korttilistaan pelaajan kortit
            PlayerCards.cardsList.Add(PlayDeck.pickCard());



            updateScene();

            if (PlayerCards.countPoints() == 21)
            {
                BlackjackWin();
            }
            else if (autoPlay == true)
            {
                autoPlayHit();
            }
        }

        private void Hit()
        {
            PlayerCards.cardsList.Add(PlayDeck.pickCard());
            updateScene();
            //pelaajan kortit yli 21 (häviää)
            if (PlayerCards.countPoints() > 21 && !autoPlay)
            {
                Lose();
            }
            // dealaerin kortit 17 ei voi ottaa lisää.
        }

        private void autoPlayHit()
        {
            bool passing = false;
            while (passing == false)
            {
                if (OddsCalculator.DealerWins(dealerCards.cardsList[1],
                   PlayerCards.countPoints()) < 50)
                {
                    passing = true;
                }
                else if (OddsCalculator.OverDraw(PlayerCards, calculateOddsDeck) <
                    OddsCalculator.DealerWins(dealerCards.cardsList[1],
                    PlayerCards.countPoints()))
                {
                    Hit();
                }
                else
                {
                    passing = true;
                }
            }
            if (PlayerCards.countPoints() > 21)
            {
                Lose();
            }
            else
            {
                pass();
            }
        }
        private void pass ()
        {
            hideFirst = false;

            while (dealerCards.countPoints() < 17)
            {
                dealerCards.cardsList.Add(PlayDeck.pickCard());
            }

            updateScene();

            if (dealerCards.countPoints() > 21)
            {
                Win();
            }
            else if (dealerCards.countPoints() == PlayerCards.countPoints())
            {
                Tie();
            }
            else if (dealerCards.countPoints() >= PlayerCards.countPoints())
            {
                Lose();
            }
            else
            {
                Win();
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (timer != null)
            {
                timer.Enabled = false;
                timer.Stop();
                timer = null;
            }
            autoPlay = false;
            updateScene();
        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }
    }
}




